using System.Net.Http.Json;
using System.Text.Json;
using WeedKillerSendGridAPI.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace WeedKillerSendGridAPI.Services;

public interface IBounceApiService
{
    Task<List<BounceRecord>> FetchBounceRecordsAsync(CancellationToken ct = default);
}

public class BounceApiService : IBounceApiService
{
    private readonly HttpClient _httpClient;
    private readonly AppSettings _settings;
    private readonly ILogger<BounceApiService> _logger;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public BounceApiService(
        HttpClient httpClient,
        IOptions<AppSettings> settings,
        ILogger<BounceApiService> logger)
    {
        _httpClient = httpClient;
        _settings = settings.Value;
        _logger = logger;

        // Set base address and optional API key header
        _httpClient.BaseAddress = new Uri(_settings.ApiEndpoint);

        if (!string.IsNullOrWhiteSpace(_settings.ApiKey))
            _httpClient.DefaultRequestHeaders.Add("X-API-Key", _settings.ApiKey);
    }

    public async Task<List<BounceRecord>> FetchBounceRecordsAsync(CancellationToken ct = default)
    {
        _logger.LogInformation("Calling API: {Endpoint}", _settings.ApiEndpoint);

        var response = await _httpClient.GetAsync(string.Empty, ct);
        response.EnsureSuccessStatusCode();

        var json = await response.Content.ReadAsStringAsync(ct);
        _logger.LogDebug("Raw API response: {Json}", json);

        // Support both a single object and an array response
        var records = TryDeserializeAsArray(json)
            ?? TryDeserializeAsSingle(json)
            ?? throw new InvalidOperationException("Unable to deserialize API response into BounceRecord(s).");

        _logger.LogInformation("Fetched {Count} bounce record(s) from API.", records.Count);
        return records;
    }

    private static List<BounceRecord>? TryDeserializeAsArray(string json)
    {
        try
        {
            var list = JsonSerializer.Deserialize<List<BounceRecord>>(json, JsonOptions);
            return list is { Count: > 0 } ? list : null;
        }
        catch { return null; }
    }

    private static List<BounceRecord>? TryDeserializeAsSingle(string json)
    {
        try
        {
            var single = JsonSerializer.Deserialize<BounceRecord>(json, JsonOptions);
            return single is not null ? [single] : null;
        }
        catch { return null; }
    }
}
