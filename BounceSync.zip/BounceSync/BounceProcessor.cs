using BounceSync.Services;
using Microsoft.Extensions.Logging;

namespace BounceSync;

public class BounceProcessor
{
    private readonly IBounceApiService _apiService;
    private readonly IDatabaseService _dbService;
    private readonly ILogger<BounceProcessor> _logger;

    public BounceProcessor(
        IBounceApiService apiService,
        IDatabaseService dbService,
        ILogger<BounceProcessor> logger)
    {
        _apiService = apiService;
        _dbService = dbService;
        _logger = logger;
    }

    public async Task RunAsync(CancellationToken ct = default)
    {
        // 1. Ensure the destination table exists
        await _dbService.EnsureTableExistsAsync(ct);

        // 2. Pull records from the API
        var records = await _apiService.FetchBounceRecordsAsync(ct);

        if (records.Count == 0)
        {
            _logger.LogWarning("No bounce records returned from API. Nothing to save.");
            return;
        }

        // 3. Persist to SQL
        var saved = await _dbService.SaveBounceRecordsAsync(records, ct);
        _logger.LogInformation("Done. {Saved}/{Total} record(s) persisted.", saved, records.Count);
    }
}
