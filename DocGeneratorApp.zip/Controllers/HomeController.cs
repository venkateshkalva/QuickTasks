using DocGeneratorApp.Models;
using DocGeneratorApp.Services;
using Hangfire;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace DocGeneratorApp.Controllers;

public class HomeController : Controller
{
    private readonly IBackgroundJobClient _backgroundJobClient;
    private readonly ILogger<HomeController> _logger;
    private readonly AppSettings _appSettings;

    public HomeController(
        IBackgroundJobClient backgroundJobClient,
        ILogger<HomeController> logger,
        IOptions<AppSettings> appSettings)
    {
        _backgroundJobClient = backgroundJobClient;
        _logger = logger;
        _appSettings = appSettings.Value;
    }

    [HttpGet]
    public IActionResult Index()
    {
        ViewBag.EmailDomain = _appSettings.EmailDomain;
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Submit([FromForm] DocumentRequestModel model)
    {
        // Parse and validate IDs
        if (string.IsNullOrWhiteSpace(model.Ids))
        {
            return Json(new { success = false, message = "Please enter at least one ID." });
        }

        var rawParts = model.Ids
            .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        var ids = new List<int>();
        var invalid = new List<string>();

        foreach (var part in rawParts)
        {
            if (int.TryParse(part, out var id) && id > 0)
                ids.Add(id);
            else
                invalid.Add(part);
        }

        if (invalid.Any())
            return Json(new { success = false, message = $"Invalid IDs detected: {string.Join(", ", invalid)}. Only positive integers are allowed." });

        if (!ids.Any())
            return Json(new { success = false, message = "No valid IDs found." });

        // Validate email (just username part; domain is fixed)
        var emailUsername = model.Email?.Trim();
        if (string.IsNullOrWhiteSpace(emailUsername))
            return Json(new { success = false, message = "Please enter your email username." });

        var fullEmail = emailUsername.Contains('@')
            ? emailUsername
            : $"{emailUsername}{_appSettings.EmailDomain}";

        // Generate a short job ID
        var jobId = $"{DateTime.UtcNow:yyyyMMddHHmmss}-{Guid.NewGuid().ToString("N")[..6].ToUpper()}";

        _logger.LogInformation("Enqueuing job {JobId} for IDs: {Ids}, notify: {Email}", jobId, string.Join(",", ids), fullEmail);

        // Enqueue Hangfire background job
        _backgroundJobClient.Enqueue<IDocumentJobService>(
            svc => svc.ProcessDocumentJobAsync(ids, fullEmail, jobId));

        return Json(new { success = true, jobId, email = fullEmail });
    }
}
