namespace DocGeneratorApp.Models;

public class AppSettings
{
    public string ApiBaseUrl { get; set; } = string.Empty;
    public string ApiEndpoint { get; set; } = string.Empty;
    public string OutputFolder { get; set; } = string.Empty;
    public string AdminEmail { get; set; } = string.Empty;
    public string EmailDomain { get; set; } = "@brongg.com";
}

public class SmtpSettings
{
    public string Host { get; set; } = string.Empty;
    public int Port { get; set; } = 587;
    public bool UseSsl { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string FromName { get; set; } = string.Empty;
    public string FromEmail { get; set; } = string.Empty;
}
