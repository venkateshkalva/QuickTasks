using System.Text.Json.Serialization;

namespace WeedKillerSendGridAPI.Models;

public class BounceRecord
{
    [JsonPropertyName("Status")]
    public string Status { get; set; } = string.Empty;

    [JsonPropertyName("reason")]
    public string Reason { get; set; } = string.Empty;

    [JsonPropertyName("email")]
    public string Email { get; set; } = string.Empty;

    [JsonPropertyName("BounceType")]
    public string BounceType { get; set; } = string.Empty;

    [JsonPropertyName("createdDate")]
    public string CreatedDate { get; set; } = string.Empty;
}
