using DocGeneratorApp.Models;
using DocGeneratorApp.Services;
using Hangfire;
using Hangfire.SqlServer;

var builder = WebApplication.CreateBuilder(args);

// ── Configuration ──────────────────────────────────────────────────────────────
builder.Services.Configure<AppSettings>(builder.Configuration.GetSection("AppSettings"));
builder.Services.Configure<SmtpSettings>(builder.Configuration.GetSection("SmtpSettings"));

// ── MVC / Razor Pages ──────────────────────────────────────────────────────────
builder.Services.AddControllersWithViews();

// ── HttpClient for the Document API ───────────────────────────────────────────
var appSettings = builder.Configuration.GetSection("AppSettings").Get<AppSettings>()!;

builder.Services.AddHttpClient("DocumentApi", client =>
{
    client.BaseAddress = new Uri(appSettings.ApiBaseUrl);
    client.Timeout = TimeSpan.FromMinutes(5);
});

// ── Application Services ───────────────────────────────────────────────────────
builder.Services.AddScoped<IEmailService, EmailService>();
builder.Services.AddScoped<IDocumentJobService, DocumentJobService>();

// ── Hangfire ───────────────────────────────────────────────────────────────────
var hangfireConn = builder.Configuration.GetConnectionString("HangfireConnection")!;

builder.Services.AddHangfire(config => config
    .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
    .UseSimpleAssemblyNameTypeSerializer()
    .UseRecommendedSerializerSettings()
    .UseSqlServerStorage(hangfireConn, new SqlServerStorageOptions
    {
        CommandBatchMaxTimeout     = TimeSpan.FromMinutes(5),
        SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
        QueuePollInterval          = TimeSpan.Zero,
        UseRecommendedIsolationLevel = true,
        DisableGlobalLocks           = true
    }));

builder.Services.AddHangfireServer(options =>
{
    options.WorkerCount = 5; // Process up to 5 jobs concurrently
});

var app = builder.Build();

// ── Middleware ─────────────────────────────────────────────────────────────────
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// Hangfire Dashboard — restrict to local in production as needed
app.UseHangfireDashboard("/hangfire", new DashboardOptions
{
    // Uncomment and customize for production auth:
    // Authorization = new[] { new HangfireAuthorizationFilter() }
});

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
