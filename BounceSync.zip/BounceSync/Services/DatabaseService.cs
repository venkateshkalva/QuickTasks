using BounceSync.Models;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace BounceSync.Services;

public interface IDatabaseService
{
    Task EnsureTableExistsAsync(CancellationToken ct = default);
    Task<int> SaveBounceRecordsAsync(IEnumerable<BounceRecord> records, CancellationToken ct = default);
}

public class DatabaseService : IDatabaseService
{
    private readonly AppSettings _settings;
    private readonly ILogger<DatabaseService> _logger;

    public DatabaseService(IOptions<AppSettings> settings, ILogger<DatabaseService> logger)
    {
        _settings = settings.Value;
        _logger = logger;
    }

    private SqlConnection CreateConnection() =>
        new(_settings.ConnectionString);

    /// <summary>
    /// Creates the BounceRecords table if it doesn't already exist.
    /// </summary>
    public async Task EnsureTableExistsAsync(CancellationToken ct = default)
    {
        var sql = $"""
            IF NOT EXISTS (
                SELECT 1 FROM sys.objects
                WHERE object_id = OBJECT_ID(N'[dbo].[{_settings.TableName}]')
                  AND type = N'U'
            )
            BEGIN
                CREATE TABLE [dbo].[{_settings.TableName}] (
                    [Id]          INT           IDENTITY(1,1) PRIMARY KEY,
                    [Status]      NVARCHAR(100) NOT NULL,
                    [Reason]      NVARCHAR(500) NOT NULL,
                    [Email]       NVARCHAR(256) NOT NULL,
                    [BounceType]  NVARCHAR(100) NOT NULL,
                    [CreatedDate] NVARCHAR(50)  NOT NULL,
                    [InsertedAt]  DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME()
                );

                CREATE INDEX IX_{_settings.TableName}_Email
                    ON [dbo].[{_settings.TableName}] ([Email]);
            END
            """;

        await using var conn = CreateConnection();
        await conn.OpenAsync(ct);
        await conn.ExecuteAsync(sql);

        _logger.LogInformation("Table [{Table}] is ready.", _settings.TableName);
    }

    /// <summary>
    /// Inserts all bounce records. Returns the number of rows saved.
    /// </summary>
    public async Task<int> SaveBounceRecordsAsync(IEnumerable<BounceRecord> records, CancellationToken ct = default)
    {
        var sql = $"""
            INSERT INTO [dbo].[{_settings.TableName}]
                ([Status], [Reason], [Email], [BounceType], [CreatedDate])
            VALUES
                (@Status, @Reason, @Email, @BounceType, @CreatedDate)
            """;

        await using var conn = CreateConnection();
        await conn.OpenAsync(ct);

        var rows = await conn.ExecuteAsync(sql, records);
        _logger.LogInformation("Saved {Rows} record(s) to [{Table}].", rows, _settings.TableName);
        return rows;
    }
}
