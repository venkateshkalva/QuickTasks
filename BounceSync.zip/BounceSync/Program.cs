using BounceSync.Models;
using BounceSync.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

var host = Host.CreateDefaultBuilder(args)
    .ConfigureAppConfiguration((context, config) =>
    {
        config.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
        config.AddEnvironmentVariables();
    })
    .ConfigureServices((context, services) =>
    {
        services.Configure<AppSettings>(context.Configuration.GetSection("AppSettings"));
        services.AddHttpClient<IBounceApiService, BounceApiService>();
        services.AddSingleton<IDatabaseService, DatabaseService>();
        services.AddTransient<BounceProcessor>();
    })
    .ConfigureLogging(logging =>
    {
        logging.ClearProviders();
        logging.AddConsole();
    })
    .Build();

var logger = host.Services.GetRequiredService<ILogger<Program>>();

try
{
    logger.LogInformation("=== BounceSync Starting ===");

    var processor = host.Services.GetRequiredService<BounceProcessor>();
    await processor.RunAsync();

    logger.LogInformation("=== BounceSync Completed Successfully ===");
}
catch (Exception ex)
{
    logger.LogCritical(ex, "Fatal error. Application shutting down.");
    Environment.Exit(1);
}
