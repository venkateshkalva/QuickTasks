namespace BounceSync.Models;

public class AppSettings
{
    public string ApiEndpoint { get; set; } = string.Empty;
    public string ApiKey { get; set; } = string.Empty;
    public string ConnectionString { get; set; } = string.Empty;
    public string TableName { get; set; } = "BounceRecords";
}
