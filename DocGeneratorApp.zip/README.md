# Doc Generator — Razor Web App

A Razor/MVC web application that accepts document IDs, calls an external API to
retrieve PDF byte arrays via Hangfire background jobs, saves them locally, and
emails the requester when done.

---

## Tech Stack

| Concern             | Technology                          |
|---------------------|-------------------------------------|
| Web Framework       | ASP.NET Core 8 MVC (Razor Views)    |
| Background Jobs     | Hangfire (SQL Server storage)       |
| HTTP Client         | `IHttpClientFactory` (named client) |
| Email               | MailKit / MimeKit (SMTP)            |
| Config              | `appsettings.json` + Options pattern|

---

## Prerequisites

- .NET 8 SDK
- SQL Server (local or remote) — for Hangfire job storage
- SMTP server accessible from the host

---

## Quick Start

### 1. Update `appsettings.json`

```json
"ConnectionStrings": {
  "HangfireConnection": "Server=.;Database=DocGeneratorHangfire;Trusted_Connection=True;TrustServerCertificate=True;"
},
"AppSettings": {
  "ApiBaseUrl":   "https://your-api-host.com",
  "ApiEndpoint":  "/api/documents/{id}",
  "OutputFolder": "C:\\DocGeneratorOutput",
  "AdminEmail":   "admin@brongg.com",
  "EmailDomain":  "@brongg.com"
},
"SmtpSettings": {
  "Host":      "smtp.brongg.com",
  "Port":      587,
  "UseSsl":    false,
  "Username":  "noreply@brongg.com",
  "Password":  "your-smtp-password",
  "FromName":  "Doc Generator",
  "FromEmail": "noreply@brongg.com"
}
```

### 2. Restore & Run

```bash
dotnet restore
dotnet run
```

Hangfire will **auto-create its SQL tables** on first run.

### 3. Open the App

Navigate to `https://localhost:7148` (or the port shown in your terminal).

---

## How It Works

```
User enters IDs + email → Submit
         │
         ▼
  HomeController.Submit()
  • Validates IDs (integers only, comma-separated)
  • Validates email username
  • Generates a Job ID (timestamp + random suffix)
  • Enqueues Hangfire background job
  • Returns JSON → JS shows confirmation dialog
         │
         ▼  (background, via Hangfire worker)
  DocumentJobService.ProcessDocumentJobAsync()
  • Creates output folder if missing
  • For each ID:
      GET {ApiBaseUrl}{ApiEndpoint?id=N}
      → byte[] response → saves as {id}.pdf
  • On completion:
      SendSuccessNotificationAsync()   ← to user + admin (if partial fail)
      SendFailureNotificationAsync()   ← to user + admin (if all fail)
```

---

## Output Folder

PDFs are saved to the path configured in `AppSettings.OutputFolder`.

```
C:\DocGeneratorOutput\
  ├── 1001.pdf
  ├── 1002.pdf
  └── 1003.pdf
```

---

## Hangfire Dashboard

Available at `/hangfire` — shows all queued, processing, succeeded, and
failed jobs. Restrict access in production via `DashboardOptions.Authorization`.

---

## Email Notifications

| Scenario         | Recipient(s)                   |
|------------------|-------------------------------|
| All succeeded    | Requester                     |
| Partial failure  | Requester + Admin             |
| Total failure    | Requester + Admin             |
| Job exception    | Requester + Admin             |

Admin email is read from `AppSettings.AdminEmail` in `appsettings.json`.

---

## Project Structure

```
DocGeneratorApp/
├── Controllers/
│   └── HomeController.cs          # Submit endpoint + validation
├── Models/
│   ├── AppSettings.cs             # Typed config models
│   └── DocumentModels.cs          # Request / job record models
├── Services/
│   ├── DocumentJobService.cs      # Hangfire job: API calls + PDF save
│   └── EmailService.cs            # MailKit SMTP notifications
├── Views/
│   ├── Home/Index.cshtml          # Main UI
│   └── Shared/_Layout.cshtml      # Layout shell
├── wwwroot/
│   ├── css/site.css               # Styling
│   └── js/site.js                 # Form validation + dialogs
├── Program.cs                     # DI, Hangfire, pipeline setup
└── appsettings.json               # All configuration
```
