(function () {
    'use strict';

    const idsInput      = document.getElementById('Ids');
    const emailInput    = document.getElementById('Email');
    const submitBtn     = document.getElementById('submitBtn');
    const idCount       = document.getElementById('idCount');
    const idError       = document.getElementById('idError');
    const emailError    = document.getElementById('emailError');
    const form          = document.getElementById('docForm');

    // ── Dialogs ──────────────────────────────────────────────
    const dialogOverlay = document.getElementById('dialogOverlay');
    const dialogMessage = document.getElementById('dialogMessage');
    const dialogJobId   = document.getElementById('dialogJobId');
    const dialogEmail   = document.getElementById('dialogEmail');
    const dialogMeta    = document.getElementById('dialogMeta');
    const dialogClose   = document.getElementById('dialogClose');

    const errorOverlay  = document.getElementById('errorOverlay');
    const errorMessage  = document.getElementById('errorMessage');
    const errorClose    = document.getElementById('errorClose');

    function showSuccess(jobId, email) {
        dialogMessage.textContent =
            'Your request has been received and is now being processed in the background. ' +
            'You will receive an email notification once all documents have been generated.';
        dialogJobId.textContent  = jobId;
        dialogEmail.textContent  = email;
        dialogMeta.style.display = 'flex';
        dialogOverlay.style.display = 'flex';
    }

    function showError(msg) {
        errorMessage.textContent    = msg;
        errorOverlay.style.display  = 'flex';
    }

    dialogClose.addEventListener('click', () => {
        dialogOverlay.style.display = 'none';
        resetForm();
    });

    errorClose.addEventListener('click', () => {
        errorOverlay.style.display = 'none';
    });

    // Close on overlay click
    [dialogOverlay, errorOverlay].forEach(overlay => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) overlay.style.display = 'none';
        });
    });

    // ── ID input — only allow digits and commas ───────────────
    idsInput.addEventListener('keydown', function (e) {
        const allowed = [
            'Backspace', 'Delete', 'Tab', 'Escape', 'Enter',
            'ArrowLeft', 'ArrowRight', 'ArrowHome', 'ArrowEnd', 'Home', 'End',
            'Comma', ','
        ];
        const isDigit     = /^\d$/.test(e.key);
        const isComma     = e.key === ',' || e.code === 'Comma';
        const isAllowed   = allowed.includes(e.key) || allowed.includes(e.code);
        const isCtrlCmd   = e.ctrlKey || e.metaKey; // allow copy/paste/select-all

        if (!isDigit && !isComma && !isAllowed && !isCtrlCmd) {
            e.preventDefault();
        }
    });

    // Additional guard: strip non-numeric/non-comma on paste / input
    idsInput.addEventListener('input', function () {
        const cursor = this.selectionStart;
        const cleaned = this.value.replace(/[^0-9,]/g, '');
        if (cleaned !== this.value) {
            this.value = cleaned;
            this.setSelectionRange(cursor - 1, cursor - 1);
        }
        updateIdCount();
        clearFieldError(idsInput, idError);
    });

    function updateIdCount() {
        const ids = parseIds(idsInput.value);
        if (ids.length > 0) {
            idCount.textContent = `${ids.length} ID${ids.length !== 1 ? 's' : ''} entered`;
        } else {
            idCount.textContent = '';
        }
    }

    function parseIds(raw) {
        return raw
            .split(',')
            .map(s => s.trim())
            .filter(s => s.length > 0 && /^\d+$/.test(s) && parseInt(s, 10) > 0);
    }

    // ── Email validation ──────────────────────────────────────
    emailInput.addEventListener('input', function () {
        clearFieldError(emailInput.closest('.email-input-wrapper') || emailInput, emailError);
    });

    // ── Form submit ───────────────────────────────────────────
    form.addEventListener('submit', async function (e) {
        e.preventDefault();

        let valid = true;

        // Validate IDs
        const ids = parseIds(idsInput.value);
        if (ids.length === 0) {
            setFieldError(idsInput, idError, 'Please enter at least one valid positive integer ID.');
            valid = false;
        }

        // Validate email username
        const emailVal = emailInput.value.trim();
        if (!emailVal) {
            setFieldError(emailInput, emailError, 'Email username is required.');
            valid = false;
        } else if (!/^[a-zA-Z0-9._\-+]+$/.test(emailVal)) {
            setFieldError(emailInput, emailError, 'Email username contains invalid characters.');
            valid = false;
        }

        if (!valid) return;

        // Show loading state
        setLoading(true);

        try {
            const formData = new FormData(form);
            const response = await fetch(form.action, {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`Server error: ${response.status}`);
            }

            const result = await response.json();

            if (result.success) {
                showSuccess(result.jobId, result.email);
            } else {
                showError(result.message || 'An unexpected error occurred. Please try again.');
            }
        } catch (err) {
            showError('Failed to submit request: ' + (err.message || 'Network error'));
        } finally {
            setLoading(false);
        }
    });

    function setLoading(loading) {
        submitBtn.disabled = loading;
        submitBtn.querySelector('.btn-text').style.display    = loading ? 'none' : 'inline';
        submitBtn.querySelector('.btn-spinner').style.display = loading ? 'inline-flex' : 'none';
    }

    function setFieldError(inputEl, errorEl, msg) {
        inputEl.classList.add('invalid');
        errorEl.textContent     = msg;
        errorEl.style.display   = 'inline';
    }

    function clearFieldError(inputEl, errorEl) {
        inputEl.classList.remove('invalid');
        errorEl.textContent     = '';
        errorEl.style.display   = 'none';
    }

    function resetForm() {
        form.reset();
        idCount.textContent         = '';
        idError.style.display       = 'none';
        emailError.style.display    = 'none';
        idsInput.classList.remove('invalid');
        emailInput.classList.remove('invalid');
    }

})();
