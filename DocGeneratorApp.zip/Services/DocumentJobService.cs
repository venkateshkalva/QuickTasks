using DocGeneratorApp.Models;
using Microsoft.Extensions.Options;

namespace DocGeneratorApp.Services;

public interface IDocumentJobService
{
    Task ProcessDocumentJobAsync(List<int> ids, string recipientEmail, string jobId);
}

public class DocumentJobService : IDocumentJobService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IEmailService _emailService;
    private readonly AppSettings _appSettings;
    private readonly ILogger<DocumentJobService> _logger;

    public DocumentJobService(
        IHttpClientFactory httpClientFactory,
        IEmailService emailService,
        IOptions<AppSettings> appSettings,
        ILogger<DocumentJobService> logger)
    {
        _httpClientFactory = httpClientFactory;
        _emailService = emailService;
        _appSettings = appSettings.Value;
        _logger = logger;
    }

    public async Task ProcessDocumentJobAsync(List<int> ids, string recipientEmail, string jobId)
    {
        _logger.LogInformation("Starting document job {JobId} for {Count} IDs", jobId, ids.Count);

        var successIds = new List<int>();
        var failedIds = new List<int>();

        // Ensure output folder exists
        var outputFolder = _appSettings.OutputFolder;
        try
        {
            Directory.CreateDirectory(outputFolder);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create output folder: {Folder}", outputFolder);
            await _emailService.SendFailureNotificationAsync(
                recipientEmail,
                _appSettings.AdminEmail,
                jobId,
                $"Could not create output directory '{outputFolder}'.\n{ex.Message}");
            return;
        }

        var client = _httpClientFactory.CreateClient("DocumentApi");

        foreach (var id in ids)
        {
            try
            {
                _logger.LogInformation("Requesting document for ID {Id}", id);

                var endpoint = _appSettings.ApiEndpoint.Replace("{id}", id.ToString());
                var response = await client.GetAsync(endpoint);

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogWarning("API returned {Status} for ID {Id}", response.StatusCode, id);
                    failedIds.Add(id);
                    continue;
                }

                var bytes = await response.Content.ReadAsByteArrayAsync();

                if (bytes == null || bytes.Length == 0)
                {
                    _logger.LogWarning("Empty response for ID {Id}", id);
                    failedIds.Add(id);
                    continue;
                }

                // Save PDF — file name is the ID
                var filePath = Path.Combine(outputFolder, $"{id}.pdf");
                await File.WriteAllBytesAsync(filePath, bytes);

                _logger.LogInformation("Saved PDF for ID {Id} to {Path}", id, filePath);
                successIds.Add(id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing ID {Id}", id);
                failedIds.Add(id);
            }
        }

        // Send completion notification
        await SendNotification(recipientEmail, jobId, successIds, failedIds);
    }

    private async Task SendNotification(string recipientEmail, string jobId, List<int> successIds, List<int> failedIds)
    {
        try
        {
            if (failedIds.Any() && !successIds.Any())
            {
                // All failed — send failure notice to user and admin
                var details = $"All {failedIds.Count} document request(s) failed.\nFailed IDs: {string.Join(", ", failedIds)}";
                await _emailService.SendFailureNotificationAsync(recipientEmail, _appSettings.AdminEmail, jobId, details);
            }
            else
            {
                // Partial or full success
                await _emailService.SendSuccessNotificationAsync(recipientEmail, successIds, failedIds, jobId);

                // Also alert admin if any failed
                if (failedIds.Any())
                {
                    var details = $"Job {jobId}: {failedIds.Count} document(s) failed.\nFailed IDs: {string.Join(", ", failedIds)}";
                    await _emailService.SendNotificationAsync(
                        _appSettings.AdminEmail,
                        $"[Doc Generator] ADMIN ALERT — Partial Failure in Job #{jobId}",
                        $"<p>{details}</p>");
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to send notification for job {JobId}", jobId);
        }
    }
}
