using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Options;
using MimeKit;
using DocGeneratorApp.Models;

namespace DocGeneratorApp.Services;

public interface IEmailService
{
    Task SendNotificationAsync(string toEmail, string subject, string body);
    Task SendSuccessNotificationAsync(string toEmail, List<int> successIds, List<int> failedIds, string jobId);
    Task SendFailureNotificationAsync(string toEmail, string adminEmail, string jobId, string errorDetails);
}

public class EmailService : IEmailService
{
    private readonly SmtpSettings _smtp;
    private readonly ILogger<EmailService> _logger;

    public EmailService(IOptions<SmtpSettings> smtp, ILogger<EmailService> logger)
    {
        _smtp = smtp.Value;
        _logger = logger;
    }

    public async Task SendNotificationAsync(string toEmail, string subject, string body)
    {
        try
        {
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(_smtp.FromName, _smtp.FromEmail));
            message.To.Add(MailboxAddress.Parse(toEmail));
            message.Subject = subject;

            var builder = new BodyBuilder { HtmlBody = body };
            message.Body = builder.ToMessageBody();

            using var client = new SmtpClient();
            await client.ConnectAsync(_smtp.Host, _smtp.Port,
                _smtp.UseSsl ? SecureSocketOptions.SslOnConnect : SecureSocketOptions.StartTlsWhenAvailable);

            if (!string.IsNullOrWhiteSpace(_smtp.Username))
                await client.AuthenticateAsync(_smtp.Username, _smtp.Password);

            await client.SendAsync(message);
            await client.DisconnectAsync(true);

            _logger.LogInformation("Email sent to {Email} with subject: {Subject}", toEmail, subject);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to send email to {Email}", toEmail);
        }
    }

    public async Task SendSuccessNotificationAsync(string toEmail, List<int> successIds, List<int> failedIds, string jobId)
    {
        var successList = successIds.Any()
            ? $"<ul>{string.Join("", successIds.Select(id => $"<li>ID {id} — PDF saved successfully</li>"))}</ul>"
            : "<p>None</p>";

        var failedList = failedIds.Any()
            ? $"<ul>{string.Join("", failedIds.Select(id => $"<li>ID {id} — Failed to retrieve</li>"))}</ul>"
            : "<p>None</p>";

        var body = $"""
            <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">
              <h2 style="color:#2d6a4f;">✅ Document Generation Complete</h2>
              <p>Your document generation job <strong>#{jobId}</strong> has finished.</p>

              <h3 style="color:#1b4332;">Successfully Generated ({successIds.Count})</h3>
              {successList}

              {(failedIds.Any() ? $"<h3 style=\"color:#c0392b;\">⚠️ Failed ({failedIds.Count})</h3>{failedList}" : "")}

              <hr style="margin:20px 0;"/>
              <p style="color:#666;font-size:12px;">This is an automated notification from Doc Generator.</p>
            </div>
            """;

        await SendNotificationAsync(toEmail, $"[Doc Generator] Job #{jobId} Complete", body);
    }

    public async Task SendFailureNotificationAsync(string toEmail, string adminEmail, string jobId, string errorDetails)
    {
        var body = $"""
            <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">
              <h2 style="color:#c0392b;">❌ Document Generation Failed</h2>
              <p>Your document generation job <strong>#{jobId}</strong> encountered an error and could not complete.</p>
              <h3>Error Details</h3>
              <pre style="background:#f8f9fa;padding:12px;border-radius:4px;font-size:13px;">{errorDetails}</pre>
              <p>Please contact support if the issue persists.</p>
              <hr style="margin:20px 0;"/>
              <p style="color:#666;font-size:12px;">This is an automated notification from Doc Generator.</p>
            </div>
            """;

        var tasks = new List<Task>
        {
            SendNotificationAsync(toEmail, $"[Doc Generator] Job #{jobId} Failed", body)
        };

        if (!string.Equals(toEmail, adminEmail, StringComparison.OrdinalIgnoreCase))
            tasks.Add(SendNotificationAsync(adminEmail, $"[Doc Generator] ADMIN ALERT — Job #{jobId} Failed", body));

        await Task.WhenAll(tasks);
    }
}
