namespace DocGeneratorApp.Models;

public class DocumentRequestModel
{
    public string Ids { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
}

public class DocumentJobRecord
{
    public int Id { get; set; }
    public byte[]? ResponseBytes { get; set; }
    public bool Success { get; set; }
    public string? ErrorMessage { get; set; }
}

public class JobResult
{
    public List<DocumentJobRecord> Records { get; set; } = new();
    public string RecipientEmail { get; set; } = string.Empty;
    public string JobId { get; set; } = string.Empty;
}
